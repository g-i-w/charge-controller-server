package bluegill;

public interface ComplexConsumer {

  public double sample ( Complex c );

}
