package bluegill;

public interface ComplexProducer {

  public Complex sample ( double sample );

}
