package bluegill;

public interface SignalPath {

	public double sample ( double inputSample );

}