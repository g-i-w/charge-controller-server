package bluegill;

public interface ComplexSignalPath {

	public Complex sample ( Complex c );
	
}