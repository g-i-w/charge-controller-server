package paddle;

public class SystemCommand extends Thread {

	private int completions;
	private String command;
	private int delay;
	private int timeout;
	private String stdout;
	private String stderr;
	private long timestampMilli;
	private long timestampNano;
	private long[] durations;
	private boolean running;
	private boolean willEnd;
	private boolean destroyed;
	private boolean destroyedForcibly;
	
	
	public SystemCommand ( String command ) {
		this( command, 0, 1, 10000, this.getClass().getName() ); // default: immediately, once, 10 second timeout, class as name
	}

	public SystemCommand ( String command, int delay, int repeat, long timeout, String name ) {
		timestampMilli = System.currentTimeMillis();
		setName( name );
		this.command = command;
		this.delay = delay;
		this.repeat = repeat;
		completions = 0;
		destroyed = false;
		destroyedForcibly = false;
		
		if (repeat < 2) {
			durations = new long[1];
		} else {
			durations = new long[repeat];
		}
	}
	
	public void preExec () {
		System.out.println( this.getClass().getName()+" '"+getName()+"' executing '"+command+"'..." );
	}
	
	public void onException ( Exception e ) {
		e.printStackTrace();
	}
	
	public void postExec () {
	
	}
	
	public run () {
		Process commandProc;
		// repeat loop
		for (int i=0; i<repeat; i++) {
			// delay before command
			while (System.currentTimeMillis() - timestampMilli < delay);
			// reset delay timer
			timestampMilli = System.currentTimeMillis();
			// preExec method
			preExec();
			// execute command
			try {
				timestampNano = System.nanoTime();
				commandProc = Runtime.getRuntime().exec( command );
				if (timeout == -1) {
					commandProc.waitFor();
				} else {
					if (!commandProc.waitFor( timeout, TimeUnit.MILLISECONDS )) {
						if (commandProc.destroy() != 0) {
							commandProc.destroyForcibly();
						}
					}
					while( commandProc != null && commandProc.isAlive() );
				}
				duration[i] = System.nanoTime() - timestampNano;
				completion++;
			} catch (Exception e) {
				duration[i] = System.nanoTime() - timestampNano;
				onException( e );
			}
			if (willEnd) break;
		}
		running = false;
	}
	
	public boolean running () {
		return running;
	}
	
	public boolean end () {
		willEnd = true;
		return willEnd;
	}
	
	public boolean 

}






